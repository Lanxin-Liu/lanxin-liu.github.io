Episode 0017, left external camera.
Each JSONL row records a source video frame, capture time in seconds, and a predicted target observation.
The masks use the resized 960 x 540 camera image. White pixels mark the target.
Bounding boxes use [xmin, ymin, xmax, ymax] in resized image pixels, with exclusive upper bounds.
The normalized box is [center_x, center_y, width, height] expressed as fractions of image width and height.
The centroid is the mean pixel position within the mask in the resized image.
The video overlay visualizes the predictions from the original DROID footage.
Source footage: DROID, Khazatsky et al., RSS 2024 (https://droid-dataset.github.io/),
licensed under CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/).
